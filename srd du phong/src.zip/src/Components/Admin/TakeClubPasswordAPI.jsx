import React from "react";

const TakeClubPasswordAPI = async (email) => {
  return <div></div>;
};

export default TakeClubPasswordAPI;
