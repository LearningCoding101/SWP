import React from "react";

const TakeClubPassword = () => {
  return <div></div>;
};

export default TakeClubPassword;
