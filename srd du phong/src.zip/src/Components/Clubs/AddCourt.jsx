import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import api from "../../config/axios";
import { Button, Form } from 'react-bootstrap';

const AddCourt = () => {
    const { clubId } = useParams();
    const [numberOfCourts, setNumberOfCourts] = useState(1);
    const [timeSlots, setTimeSlots] = useState([]);
    const [selectedTimeSlots, setSelectedTimeSlots] = useState([]);

    useEffect(() => {
        api.get('/timeslots')
            .then(response => setTimeSlots(response.data))
            .catch(error => console.error('Error fetching time slots:', error));
    }, []);

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {

            const courtCreateRequestCombo = { numberofcourt: numberOfCourts, tsid: selectedTimeSlots };

            console.log('Request payload:', courtCreateRequestCombo);
            await api.post(`court/manycourts/${clubId}`, courtCreateRequestCombo);
            alert('Courts created successfully');
        } catch (error) {
            console.error('Error creating courts:', error);
            alert('Error creating courts');
        }
    };

    const handleTimeSlotChange = (event) => {
        const selectedOptions = Array.from(event.target.selectedOptions, option => Number(option.value));
        setSelectedTimeSlots(selectedOptions);
    };

    return (
        <div>
            <h1>Add Courts</h1>
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicNumberOfCourts">
                    <Form.Label>Number of Courts</Form.Label>
                    <Form.Control type="number" value={numberOfCourts} onChange={(e) => setNumberOfCourts(e.target.value)} />
                </Form.Group>
                <Form.Group controlId="formBasicTimeSlots">
                    <Form.Label>Time Slots</Form.Label>
                    <Form.Control as="select" multiple value={selectedTimeSlots} onChange={handleTimeSlotChange}>
                        {timeSlots.map(timeSlot => (
                            <option key={timeSlot.timeslotId} value={timeSlot.timeslotId}>
                                {`${timeSlot.start_time} - ${timeSlot.end_time}`}
                            </option>
                        ))}
                    </Form.Control>
                </Form.Group>
                <Button variant="warning" type="submit">
                    Submit
                </Button>
            </Form>
        </div>
    );
}

export default AddCourt;
