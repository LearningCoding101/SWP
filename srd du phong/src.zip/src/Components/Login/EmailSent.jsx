import React from 'react'

const EmailSent = () => {
    return (
        <div className='login-container'>
            <div className='login-card'>
                <div className='forgotPass-text'>
                    <h3>Email sent </h3>
                    <p>We have sent a request to you. Check your inbox to reset password</p>
                </div>
            </div>
        </div>
    )
}

export default EmailSent