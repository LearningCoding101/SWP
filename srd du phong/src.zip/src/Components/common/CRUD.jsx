import React from 'react'
import AddClub from '../Clubs/AddClub';

const CRUD = () => {
  return (
    <div>
        <AddClub />
    </div>
  )
}

export default CRUD